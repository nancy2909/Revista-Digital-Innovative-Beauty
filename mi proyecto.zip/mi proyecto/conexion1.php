<?php
$conexion=mysqi_connect("localhost","root","conaleptemixco1","agenda");
if(!conexion) {
echo "error al conectar la base de datos";
}else{
}
echo"conectado:"; 